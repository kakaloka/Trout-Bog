#include "RDPIDQuery.h"

RDPIDQuery::RDPIDQuery()
{
}

RDPIDQuery::~RDPIDQuery()
{
    RDPID.clear();
}

int RDPIDQuery::load(string fname)
{
    fstream RDPfasta;
    RDPfasta.open(fname.c_str());
    if(RDPfasta.fail()){cout<<"cannot open RDP fasta file! This will not affect normal functions\n"; return 0;}
    while(!RDPfasta.eof())
    {
        string tLine;
        getline(RDPfasta, tLine);
        if(tLine[0]=='>')
        {
            size_t found=tLine.find_last_of(" ,\t");
            string tGBID=tLine.substr(found+1);
            found=tLine.find_first_of(" ,\t");
            string tRDPID=tLine.substr(1, found-1);
            RDPID[tGBID]=tRDPID;
        }
    }
    RDPfasta.close();
    return 1;
}

string RDPIDQuery::get_RDPID(string tGBID)
{
    return RDPID[tGBID];
}
