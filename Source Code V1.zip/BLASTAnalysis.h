/********************************
* Author: Xiaolin Hao
* Date:   2010-04-29
* Description:
* Class for parsinig BLAST result
*********************************/


#ifndef __BLASTANALYSIS_H__
#define __BLASTANALYSIS_H__

#include "common.h"
#include "RDPIDQuery.h"
#include "GBProcessing.h"
#include "MinCover.h"
#include "MLE.h"

using namespace std;

typedef struct _Criterion{
       float Evalue_Threshold;
       float Identity_Threshold;
       int MappingLength_Threshold;
}Criterion;


typedef struct _MappingInfo{
       int ReadStart;
       int ReadEnd;
       int TemplateStart;
       int TemplateEnd;
       float Identity;
       float Evalue;
       int Length;
       float Score;
}MappingInfo;


class BLASTResult{
      private:
             Criterion Thresholds;
             //string* ReadName;
             //string* TemplateName;
             map<string, double> DBAbundance;        //sequence abundance information in the database used
             map<string, double> Abundance;          //hits distribution
             map<string, map<string, MappingInfo> > MappingResult; //mapping result loaded from BLAST -m 8 output
             map<string, string> BestHits;
             vector<string> Keywords;
             char** line_proc(char*);
             int read_mapping_info(string, string, char**);
             int normalize(map<string,double>&,int,string);  //calulate the weight of each hit (when there are multiple hits in BLAST) 
             bool Filter(MappingInfo, Criterion);    //set cut-off for identity, mapping length, e-value, etc.
             int ambiguity_detect(string, string, GBProcessing&, RDPIDQuery&, map<string, double>&, int);
             int assignment_test(string, GBProcessing&, RDPIDQuery&, int);
             MinimumCover MC;
             MaximumLikelihoodEstimate MLE;
              
      public:
             BLASTResult();
             BLASTResult(float,float,int);
             ~BLASTResult();
             map<string,double>::iterator Iterator; 
             map<string, map<string, MappingInfo> >::iterator MappingIterator;
             map<string, map<string, double> > ReadDistr;
             void DBAbundance_set(string, double);
             void Iterator_reset();
             bool Iterator_end();
             int MappingIterator_size();
             void MappingIterator_reset();
             bool MappingIterator_end();
             int Import(string, GBProcessing&, RDPIDQuery&, int, int);
             int Import_Hierarchy(string, GBProcessing&, RDPIDQuery&, int, int);
             int Import_Pairend(string, GBProcessing&, RDPIDQuery&, int, int);
             int OutputSequence(string);
             string get_SeqID(int);
             int get_size();
             double get_abundance(int); 
             int set_Abundance(map<string,double>&);
             int SetThresholds(float,float,int); 
             int AmbiCount;
};



#endif
