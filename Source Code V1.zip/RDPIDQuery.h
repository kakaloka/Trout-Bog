#ifndef __RDPIDQuery_H__
#define __RDPIDQuery_H__

#include "common.h"

class RDPIDQuery{
      private:
             map<string, string> RDPID;
      public:
             RDPIDQuery();
             ~RDPIDQuery();
             int load(string);
             string get_RDPID(string);
      };


#endif
