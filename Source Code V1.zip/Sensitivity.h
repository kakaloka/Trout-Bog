/********************************
* Author: Xiaolin Hao
* Date:   2011-07-20
* Description:
* Class for calculating pairwise 
* Sensitivity
*********************************/

#ifndef __Sensitivity_H__
#define __Sensitivity_H__

#include "common.h"

class Sensitivity{
      private:
      
      public:
             Sensitivity();
             ~Sensitivity();
             double** calc(map<string,double*>&, int, double**);
      };



#endif
