/********************************
* Author: Xiaolin Hao
* Date:   2012-02-12
* Description:
* For Minimum Cover Problem
*********************************/

#ifndef __MINCOVER_H__
#define __MINCOVER_H__

#include "common.h"

class MinimumCover{
      private:
          
      public:
          MinimumCover();
          ~MinimumCover();
          vector<string> SelectedGroups;   
          int greedy_minimum_cover(map<string, map<string, double> >);
      };
      
#endif
