/***********************************
* Author: Xiaolin Hao
* Date:   2010-04-29
* Description:
* Integrate information from BLAST 
* and RDP and calculate statistics
************************************/

#ifndef __ANALYSIS_H__
#define __ANALYSIS_H__

#include "common.h"
#include "RDPIDQuery.h"
#include "BLASTAnalysis.h"
#include "GBProcessing.h"
#include "JaccardIndex.h"
#include "Sensitivity.h"
#include "ThetaIndex.h"
#include "BrayCurtis.h"
#include "Wilcoxon.h"
#include <gsl/gsl_randist.h>

class AnalysisPipeline{
      private:
             double Threshold;
             int SampleNum;
             double* DataSize;
             int* AmbiSize;
             
             //****** RDP Processing *****
             GBProcessing GenBank;
             RDPIDQuery RDPQuery;
             int TaxonomicLevel;
             //***************************
             
             //****** BLAST Processing *****
             BLASTResult* BLASTMapping;
             float BLASTEvalueThreshold;
             float BLASTIdentityThreshold;
             int BLASTMappingLengthThreshold;
             map<string,string> RawMapping; 
             //*****************************
             
             //****** Theta Index value ******
             ThetaIndex Theta;
             double** ThetaIndexValue;
             //*******************************
             
             //****** Bray Curtis dissmilarity *****
             BrayCurtis BCurtis;
             double** BrayCurtisDissimilarity;
             //*************************************
             
             //****** Jaccard Index value ******
             JaccardIndex Jaccard;
             double** JaccardIndexValue;
             //*********************************
             
             //****** Sensitivity *******
             Sensitivity Sensitive;
             double** SensitivityMatrix;
             //**************************
             
             //****** Wilcoxon Test *******
             Wilcoxon Wil;
             map<string, double*> WilcoxonScore;
             double*** WilcoxonMatrixSensitivity;
             double*** WilcoxonMatrixSpecificity;
             double*** WilcoxonMatrixBrayCurtis;
             //****************************
             
             //****** Median Normalization ******
             void normalize_median();
             double find_median(double*, int);
             double* Median;
             //**********************************
              
             map<string, double*> Abundance;
             double** Dist;
             double** T;
             double* InitialGuess;
             map<string, int> TaxonomyID;
             vector<string> rTaxonomyID;
             map<string, int> QueryID;
             void dist_calc(int);
             int infer_taxonomy(int, bool);
             int EM(int); 
             int infer_taxonomy_EM();
             int infer_taxonomy_new();
             
             
      public:
             AnalysisPipeline(int,float,float,int,int);
             ~AnalysisPipeline();
             int open(string*, string, bool, int, bool, bool, bool);
             int output(string, bool);
             int load_taxonomy(string);
             int statistics(bool);
      };


#endif
