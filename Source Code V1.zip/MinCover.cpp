#include "MinCover.h"
MinimumCover::MinimumCover()
{
                            
}

MinimumCover::~MinimumCover()
{
    SelectedGroups.clear();                        
}

int MinimumCover::greedy_minimum_cover(map<string, map<string, double> > ReadDistr)
{
    cout<<"Min Cover Start\n";
    map<string, double> Count;
    double tMax;
    string tMaxIndex;
    while(!ReadDistr.empty())
    {
        map<string, map<string, double> >::iterator it=ReadDistr.begin();
        tMax=0.0;
        while(it!=ReadDistr.end())
        {
            map<string, double>::iterator it2=(*it).second.begin();
            while(it2!=(*it).second.end())
            {
                map<string, double>::iterator it3=Count.find((*it2).first);
                if(it3!=Count.end())
                    Count[(*it2).first]+=(*it2).second;
                else
                    Count[(*it2).first]=(*it2).second;
                if(Count[(*it2).first]>=tMax)
                {
                    tMax=Count[(*it2).first];
                    tMaxIndex=(*it2).first;
                }
                it2++;
            }
            it++;
        }
        cout<<tMaxIndex<<"\t"<<tMax;
        SelectedGroups.push_back(tMaxIndex);
        it=ReadDistr.begin();
        while(it!=ReadDistr.end())
        {
            map<string, double>::iterator it2=(*it).second.find(tMaxIndex);
            if(it2!=(*it).second.end())
            {
                map<string, map<string, double> >::iterator pos=it;
                it++;
                ReadDistr.erase(pos);
                continue;
            }
            it++;
        }
        cout<<"\t"<<ReadDistr.size()<<"\t";
    }
    return 1;
}
