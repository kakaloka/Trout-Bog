/********************************
* Author: Xiaolin Hao
* Date:   2010-04-29
* Description:
* Class for Wilcoxon Signed Rank Test
*********************************/

#ifndef __Wilcoxon_H__
#define __Wilcoxon_H__

#include "common.h"

class Wilcoxon{
      private:
            double* abs_bubble_sort(double*, int);
            double* rank(double*, int);  
      public:
             Wilcoxon();
             ~Wilcoxon();
             double wilcoxon_signed_rank_test(double*, double*, int);
             double wilcoxon_rank_sum_test(double*, double*, int, int); 
             void swap(double&, double&);     
      };



#endif
