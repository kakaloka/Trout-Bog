/********************************
* Author: Xiaolin Hao
* Date:   2012-02-12
* Description:
* For Maximum Likelihood
*********************************/

#ifndef __MLE_H__
#define __MLE_H__

#include "common.h"
#include "RDPIDQuery.h"
#include "GBProcessing.h"

class MaximumLikelihoodEstimate{
      private:
          map<string, string> AssignmentData;
          int check_assignment_accuracy(string, RDPIDQuery&, GBProcessing&, int);
      public:
          MaximumLikelihoodEstimate();
          ~MaximumLikelihoodEstimate();
          map<string,double> MLEAbund;   
          int maximum_likelihood_estimate(map<string, map<string, double> >&, vector<string>&);
      };
      
#endif
