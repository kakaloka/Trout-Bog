/********************************
* Author: Xiaolin Hao
* Date:   2010-04-29
* Description:
* Class for calculating pairwise 
* Theta Index values
*********************************/

#ifndef __ThetaIndex_H__
#define __ThetaIndex_H__

#include "common.h"

class ThetaIndex{
      private:
      
      public:
             ThetaIndex();
             ~ThetaIndex();
             double** calc(map<string,double*>&, int, double**);
      };



#endif
