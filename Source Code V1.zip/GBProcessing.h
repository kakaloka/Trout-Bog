/********************************
* Author: Xiaolin Hao
* Date:   2010-04-29
* Description:
* Class for extracting taxonomy
* information from GenBank file
*********************************/

#ifndef __GBProcessing_H__
#define __GBProcessing_H__

#include "common.h"

const string Level[9]={"norank","domain","phylum","class","subclass","order","suborder","family","genus"};

class GBProcessing{
      private:
             int DBSeqNum;
             map<string, map<string,string> > Taxonomy;
             map<string,int> TaxonAbundance; //abundance of genus "string"
             map<string,int> SeqAbundance;  // abundance of the genus that sequence "string" belongs to
             char* string_to_char(string);
             string post_proc(string);
      public:
             GBProcessing();
             ~GBProcessing();
             map<string,int>::iterator GBIterator;
             void Iterator_reset(int);
             bool Iterator_end(int);
             int Iterator_size(int);
             string get_Taxonomy(string, int);
             int extract_taxonomy(string);
             int load_taxonomy(string);
             int output_taxonomy(string);
             void Tokenize(const string&, vector<string>&, const string&);
             //int get_SeqAbundance(string);
      };



#endif
