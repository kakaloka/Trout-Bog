#include "ThetaIndex.h"

ThetaIndex::ThetaIndex()
{
}

ThetaIndex::~ThetaIndex()
{
}

double** ThetaIndex::calc(map<string,double*>& Abundance, int SampleNum, double** ThetaIndexMatrix)
{
    int tPairs=SampleNum*(SampleNum-1)/2;
    double* tX=new double[tPairs];         //sum of abundance of first community
    memset(tX,0,sizeof(double)*tPairs);  
    double* tY=new double[tPairs];         //sum of abundance of second community
    memset(tY,0,sizeof(double)*tPairs);
    map<string,double*>::iterator it=Abundance.begin();
    while(it!=Abundance.end())
    {
        for(int i=0;i<SampleNum-1;i++)
            for(int j=i+1;j<SampleNum;j++)
            {
                int tIndex=i*SampleNum-i*(i+1)/2+j-i-1;
                if((*it).second[i]!=0&&(*it).second[j]!=0)
                {
                    tX[tIndex]+=(*it).second[i];
                    tY[tIndex]+=(*it).second[j];
                }
            }
        it++;
    }
    for(int i=0;i<SampleNum;i++)
        for(int j=0;j<SampleNum;j++)
        {
            if(i==j)
                ThetaIndexMatrix[i][j]=1.0;
            if(i>j)
                ThetaIndexMatrix[i][j]=ThetaIndexMatrix[j][i];
            if(i<j)
            {
                int tIndex=i*SampleNum-i*(i+1)/2+j-i-1;
                ThetaIndexMatrix[i][j]=(tX[tIndex]*tY[tIndex])/(tX[tIndex]+tY[tIndex]-tX[tIndex]*tY[tIndex]);
            }
            //cout<<ThetaIndexMatrix[i][j];
            //if(j==SampleNum-1)
                //cout<<"\n";
            //else
                //cout<<"\t";
        }
    delete[] tX;
    delete[] tY;
    return ThetaIndexMatrix;
}
