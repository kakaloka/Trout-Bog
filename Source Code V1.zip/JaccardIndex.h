/********************************
* Author: Xiaolin Hao
* Date:   2011-07-20
* Description:
* Class for calculating pairwise 
* Jaccard Index values
*********************************/

#ifndef __JaccardIndex_H__
#define __JaccardIndex_H__

#include "common.h"

class JaccardIndex{
      private:
      
      public:
             JaccardIndex();
             ~JaccardIndex();
             double** calc(map<string,double*>&, int, double**);
      };



#endif
