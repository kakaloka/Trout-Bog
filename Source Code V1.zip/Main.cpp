#include  "AnalysisPipeline.h"

char* program = NULL;

int main(int argc, char* argv[])
{
    int next_option;
	/* A string listing valid short options letters. */
	const char* const short_options = "i:j:o:n:E:I:L:JO:MWDl:";
	/* An array describing valid long options. */
	const struct option long_options[] = {
		{"input", 0, NULL, 'i'},
		{"genbank input", 0, NULL, 'j'},
		{"output", 0, NULL, 'o'},
		{"number of sample", 0, NULL, 'n'},
		{"e-value cut-off", 0, NULL, 'E'},
		{"identity cut-off", 0, NULL, 'I'},
		{"mapping length cut-off", 0, NULL, 'L'},
		{"if force taxon construction", 0, NULL, 'J'},
		{"assign different normalizing methods", 0, NULL, 'O'},
		{"EM flag", 0, NULL, 'M'},
		{"Wilcoxon flag", 0, NULL, 'W'},
		{"Median normalization flag", 0, NULL, 'D'},
		{"Taxonomic level", 0, NULL, 'l'},
		{NULL, 0, NULL, 0}
	};
	program = argv[0];
	char* tFile=NULL;
    string OutputFile="Default_Output", *InputFiles, GenBankInputFile;
	int n=1, len=0, L=45;
	float E=1e-15, I=95;
	bool BuildTaxonFlag=false; 
	bool EMFlag=false;
	bool WilcoxonFlag=false;
	bool MedianNormalizationFlag=false;
    int OperationFlag=2;
    int TaxonomicLevel=8;
	do{
		next_option = getopt_long(argc, argv, short_options, long_options, NULL);
		switch(next_option){
			case 'i': 
                len=strlen(optarg);
                tFile=new char[len+1];
                memset(tFile,0x00,sizeof(char)*(len+1));
                memcpy(tFile, optarg, len);
				break;
			case 'j':
                 GenBankInputFile.assign(optarg);
                 break;
            case 'o':
                 OutputFile.assign(optarg);
                 break;
            case 'n':
                 n=atoi(optarg);
                 break;
            case 'E':
                 E=atof(optarg);
                 break;
            case 'I':
                 I=atof(optarg);
                 break;
            case 'J':
                 BuildTaxonFlag=true;
                 break;
            case 'O':
                 OperationFlag=atoi(optarg);
                 break;                 
            case 'L':
                 L=atoi(optarg);
                 break;
            case 'M':
                 EMFlag=true;
                 break;
            case 'W':
                 WilcoxonFlag=true;
                 break;
            case 'D':
                 MedianNormalizationFlag=true;
                 break;
            case 'l':
                 TaxonomicLevel=atoi(optarg);
                 break;
			case -1: /* Done with options */
				 break;
			default: /* Unexpected */
				cout<<"Unexpected argument was taken."<<endl;
		}
	}while(next_option != -1);
	InputFiles=new string[n];
	if(n==1)
	     InputFiles[0].assign(tFile);
    cout<<InputFiles[0]<<endl;
    
	if(n>1)
	{
         char* pch;
         pch=strtok(tFile,",");
         for(int i=0;i<n;i++)
         {
              InputFiles[i].assign(pch);
              pch=strtok(NULL,",");
              cout<<InputFiles[i]<<"\n";
         }
         if(pch!=NULL) delete[] pch;
    }
    /*
    int count=0;
   	if(n>1)
	{
         char* pch;
         pch=strtok(tFile,",");
         while(pch!=NULL)
         {
             InputFiles[count].assign(pch);
             cout<<InputFiles[count]<<"\n";
             count++;
             pch=strtok(NULL,",");            
         }
    string Sample[18]={"TS1_","TS2_","TS3_","TS4_","TS5_","TS6_","TS7_","TS8_","TS9_","TS19_","TS20_","TS21_","TS28_","TS29_","TS30_","TS49_","TS50_","TS51_"};
    string Length[6]={"50_","65_","85_","100_","150_","200_"};
    string Number[9]={"100_","200_","400_","800_","1000_","2000_","4000_","8000_","10000_"};
    string Error[3]={"0%_","1%_","2%_"};
    string Index[10]={"1","2","3","4","5","6","7","8","9","10"};
    
    count=count-2;
    //count=count-1;
    
    string Prefix1=InputFiles[count];
    string Prefix2=InputFiles[count+1];
    for(int j=0;j<5;j++)
        for(int k=0;k<10;k++)
        {
            InputFiles[count]=Prefix1+Number[j]+Index[k]+".fasta.out";
            cout<<InputFiles[count]<<"\n";
            count++;
        }
    
    
    
    for(int i=0;i<6;i++)
        for(int j=0;j<9;j++)
            for(int k=0;k<10;k++)
            {
               InputFiles[count]=Prefix2+Length[i]+Number[j]+Error[0]+Index[k]+".fasta.out";
               cout<<InputFiles[count]<<"\n";
               count++;
            }
    
    /*
     string Prefix[5];
     for(int i=0;i<5;i++)
         Prefix[i]=InputFiles[i];
     count=0;
     for(int i=1;i<5;i++)
         for(int j=0;j<18;j++)
         {
             InputFiles[count]=Prefix[0]+Sample[j]+Prefix[i];
               cout<<InputFiles[count]<<"\n";
             count++;
         }
     */
    //} //if(n>1)
    AnalysisPipeline AP(n,E,I,L,TaxonomicLevel);
    cout<<GenBankInputFile<<endl;
    if(AP.AnalysisPipeline::open(InputFiles,GenBankInputFile,BuildTaxonFlag,OperationFlag,EMFlag,WilcoxonFlag,MedianNormalizationFlag))
        AP.output(OutputFile, WilcoxonFlag);
    system("pause");
	return 1;
}
