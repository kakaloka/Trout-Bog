/********************************
* Author: Xiaolin Hao
* Date:   2010-05-03
* Description:
* Class for calculating pairwise 
* Bray-Curtis dissimilarity
*********************************/

#ifndef __BrayCurtis_H__
#define __BrayCurtis_H__

#include "common.h"

class BrayCurtis{
      private:
      
      public:
             BrayCurtis();
             ~BrayCurtis();
             double** calc(map<string,double*>&, int, double**);      
      };

#endif

